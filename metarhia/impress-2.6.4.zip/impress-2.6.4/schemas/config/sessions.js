({
  sid: 'string',
  characters: 'string',
  length: 'number',
  secret: 'string',
  regenerate: 'number',
  expire: 'number',
  persistent: 'boolean',
  limits: {
    ip: 'number',
    user: 'number',
  },
});
