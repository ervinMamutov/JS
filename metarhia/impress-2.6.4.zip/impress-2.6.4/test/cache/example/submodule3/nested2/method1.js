() => {
  console.debug('Call method: example.submodule3.nested2.method1');
};
