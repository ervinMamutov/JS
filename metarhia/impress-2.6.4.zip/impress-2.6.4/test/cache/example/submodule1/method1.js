() => {
  console.debug('Call method: example.submodule1.method1');
};
