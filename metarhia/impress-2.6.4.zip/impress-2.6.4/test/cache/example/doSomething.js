() => {
  console.debug('Call method: example.doSomething');
};
